
<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Create table</h4>
                </div>
                <div class="">
                           <div>
                            <form method="post" action="<?php echo e(URL::to('category-store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="basic-form">
                                        <input type="hidden" name="category_id" value="<?php echo e((!empty($category->id))?$category->id:''); ?>" class="form-control input-default ">
                                        <h4 class="card-title">Title</h4>
                                        <div class="mb-3">
                                            <input type="text" name="title" value="<?php echo e((!empty($category->title))?$category->title:old('title')); ?>" class="form-control input-default ">
                                            <?php if($errors->has('title')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                                            <?php endif; ?>
                                        </div><br>
                                        <h4 class="card-title">Discription</h4>
                                        <div class="mb-3">
                                            <textarea name="description" class="form-control" rows="4" id="comment"><?php echo e((!empty($category->description))?$category->description:old('description')); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Add</button>
                                </div>

                            </form>
                        </div>
                       
                    <div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/category/createCategory.blade.php ENDPATH**/ ?>