
<?php $__env->startSection('admin'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Create Product</h4>
                </div>
                <div>
                    <form method="post" action="<?php echo e(URL::to('store-product')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="basic-form">
                                <h4 class="card-title">Title</h4>
                                <div class="mb-3">
                                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control input-default ">
                                    <?php if($errors->has('title')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                                    <?php endif; ?>
                                </div><br>
                                <h4 class="card-title">Short Description</h4>
                                <div class="mb-3">
                                    <textarea name="short_description" class="form-control" rows="3" id="comment"></textarea>
                                    <?php if($errors->has('short_description')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('short_description')); ?></span>
                                    <?php endif; ?>
                                </div><br>
                                <div class="mb-3">
                                    <h4 class="card-title">Select Category</h4>
                                    <select name="category_id" class="default-select form-control wide mb-3">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('category_id')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('category_id')); ?></span>
                                    <?php endif; ?>
                                </div><br>
                                <div class="mb-3">
                                    <input type="text" name="stock_price" value="<?php echo e(old('stock_price')); ?>" class="form-control input-default ">
                                    <?php if($errors->has('stock_price')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('stock_price')); ?></span>
                                    <?php endif; ?>
                                </div><br>
                                <div class="mb-3">
                                    <input type="text" name="selling_price" value="<?php echo e(old('selling_price')); ?>" class="form-control input-default ">
                                    <?php if($errors->has('stock_price')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('selling_price')); ?></span>
                                    <?php endif; ?>
                                </div><br>
                                <div id="addR">
                                    <span class="input-group-btn">
                                        <button id="addAttributeButton" type="button" class="btn btn-success add-product-div"><i class="glyphicon glyphicon-plus"></i>+</button>
                                    </span>
                                    <div id="select-wrapper">
                                        <div id="element-wrapper" class="row">
                                            <?php $__currentLoopData = $all_attribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($attributes->type=='size'): ?>
                                                <div class="mb-3 col-2">
                                                    <div class="align-items-center">
                                                        <div class="col-auto my-1">
                                                            <label class="me-sm-2"><?php echo e($attributes->name); ?></label>
                                                            <select name="attribute_size_values[]" class="me-sm-2 default-select form-control wide" id="inlineFormCustomSelect">
                                                                <option selected="">Choose...</option>
                                                                <?php $__currentLoopData = $attributes->attribute_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($attr_value->name); ?>"><?php echo e($attr_value->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php elseif($attributes->type=='color'): ?>
                                                <div class="mb-3 col-2">
                                                    <div class="align-items-center">
                                                        <div class="col-auto my-1">
                                                            <label class="me-sm-2"><?php echo e($attributes->name); ?></label>
                                                            <select name="attribute_color_values[]" class="me-sm-2 default-select form-control wide" id="inlineFormCustomSelect">
                                                                <option selected="">Choose...</option>
                                                                <?php $__currentLoopData = $attributes->attribute_value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($attr_value->name); ?>"><?php echo e($attr_value->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php endif; ?>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-3 col-2">
                                                <div class="align-items-center">
                                                    <div class="col-auto my-1">
                                                        <label class="me-sm-2">Quantity</label>
                                                        <input type="text" name="quantity[]" value="" class="form-control input-default ">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <br><span class="input-group-btn"><button type="button" class="btn btn-danger remove-attribute-element"><i class="glyphicon glyphicon-minus"></i>-</button></span>
                                        </div>
                                    </div>
                                </div><br>
                                <h4 class="card-title">Description</h4>
                                <div class="mb-3">
                                    <div class="card-body custom-ekeditor">
                                        <textarea id="ckeditor" name="description" class="form-control"></textarea>
                                    </div>
                                    <?php if($errors->has('description')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                    <?php endif; ?>
                                </div><br>
                                <h4 class="card-title">Main Image</h4>
                                <div class="input-group">
                                    <div class="form-file">
                                        <input type="file" name="main_image" class="form-file-input form-control">
                                    </div>
                                    <?php if($errors->has('main_image')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('main_image')); ?></span>
                                    <?php endif; ?>
                                </div><br>
                                <div class="mb-3">
                                    <div class="textbox-wrapper-img">
                                        <div class="input-wrapper-img">
                                            <h4 class="card-title">More Images</h4>
                                            <div class="input-group">
                                                <input type="file" name="more_images[]" class="form-file-input form-control" />
                                                <span class="input-group-btn">
                                                    <button type="button" class="btn btn-success add-textbox-img"><i class="glyphicon glyphicon-plus"></i>+</button>
                                                </span>
                                            </div><br>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary">Add</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/product/create.blade.php ENDPATH**/ ?>